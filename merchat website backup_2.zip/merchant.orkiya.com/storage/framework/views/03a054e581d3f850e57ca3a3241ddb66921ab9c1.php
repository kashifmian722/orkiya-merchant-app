<script type="text/javascript">
    <?php if(Session::has("error")): ?>
        toastr.error("<?php echo Session::get('error'); ?>");
    <?php endif; ?>
    <?php if(Session::has("success")): ?>
    	toastr.success( "<?php echo Session::get('success'); ?>")
    <?php endif; ?>
    <?php if(Session::has("info")): ?>
    	toastr.info("<?php echo Session::get('info'); ?>")
    <?php endif; ?>
</script><?php /**PATH /home/orkiya-merchant/htdocs/merchant.orkiya.com/resources/views/layouts/toast.blade.php ENDPATH**/ ?>