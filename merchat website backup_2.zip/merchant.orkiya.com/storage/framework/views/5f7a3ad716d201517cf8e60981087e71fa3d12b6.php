<div class="overlay" id="loading_screen">
    <div class="loader">
        <div class="circle"></div>
        <div class="circle"></div>
        <div class="circle last"></div>
        <div class="circle clear"></div>
        <div class="circle"></div>
        <div class="circle last"></div>
        <div class="circle clear"></div>
        <div class="circle "></div>
        <div class="circle last"></div>
    </div>
</div><?php /**PATH /home/orkiya-merchant/htdocs/merchant.orkiya.com/resources/views/layouts/loading.blade.php ENDPATH**/ ?>