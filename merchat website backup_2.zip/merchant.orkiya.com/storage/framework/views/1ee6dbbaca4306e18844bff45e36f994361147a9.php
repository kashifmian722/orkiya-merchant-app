<?php $__env->startSection('style'); ?>
<style type="text/css">
	.form-control{
		padding: 1rem !important;
		background-color: #e5e5e5 !important;
	}
    .output_image{
        width: 25%;
    }
    #second_level_dropdown, #third_level_dropdown{
        display: none;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
    	<div class="card my-4">
    		<div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
    			<div class="bg-gradient-primary shadow-primary border-radius-lg pt-3 pb-4">
    				<div class="row">
	                    <div class="col-6 d-flex align-items-center">
	                    	<h6 class="text-white text-capitalize ps-3">Edit Product</h6>
	                    </div>
                  	</div>
    			</div>
    		</div>
    		<div class="card-body px-0 pb-2">
    			<div class="table-responsive p-0">
    				<form class="align-items-center mx-5" id="product_form" action="<?php echo e(url('/products/edit/'.$product['id'])); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
    					<div class="form-group ">
    						<label for="productType">Product Type</label>
    						<select class="form-control" id="productType" name="type">
                                <option value="">Select Product Type</option>
    							<option value="product" <?php if( $product['productType'] == "product"): ?> selected="" <?php endif; ?>>Product</option>
      							<option value="storeWindow" <?php if( $product['productType'] == "storeWindow"): ?> selected="" <?php endif; ?>>Showcase</option>
                                
    						</select>
    					</div>
                        <div class="form-group mt-2">
                            <label for="assignedCategories">Assigned Categories</label>
                            <?php $__currentLoopData = $product['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge badge-sm bg-gradient-success"><?php echo e($category['name']); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="form-group ">
                            <label for="category">Category</label>
                            <select class="form-control" id="category_level_1" name="category_level_1">
                                <option value="">Select Category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option value="<?php echo e($cat['id']); ?>"><?php echo e($cat['name']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group" id="second_level_dropdown">
                            <label for="category">Category</label>
                            <select class="form-control" id="category_level_2" name="category_level_2">
                                
                            </select>
                        </div>
                        <div class="form-group" id="third_level_dropdown">
                            <label for="category">Category</label>
                            <select class="form-control" id="category_level_3" name="category_level_3">
                                
                            </select>
                        </div>
    					<div class="form-group mt-2">
    						<label for="productName">Product Name</label>
    						<input type="text" class="form-control" id="productName" name="name" placeholder="Enter Product Name" value="<?php echo e($product['name']); ?>">
    					</div>
    					<div class="form-group mt-2">
    						<label for="productDescription">Description</label>
                            <textarea class="form-control ckeditor" id="productDescription" name="description"><?php echo e($product['description']); ?></textarea>
    					</div>
    					<div class="form-group form-check form-switch ps-0 pt-3">
    						<input class="form-check-input ms-auto" type="checkbox" id="productStatus" name="status" <?php if($product['active']): ?> checked <?php endif; ?>>
                            <label class="form-check-label text-body ms-3 text-truncate w-80 mb-0" for="productStatus">Active</label>
    					</div>
                        <div id="price_section" <?php if( $product['productType'] == "storeWindow"): ?> style="display: none;" <?php endif; ?>>
                            <div class="form-group mt-2">
                                <label for="productPrice">Price</label>
                                <input type="number" class="form-control" id="productPrice" placeholder="Enter Price" name="price" value="<?php echo e($product['price']); ?>">
                            </div>
                            <div class="form-group mt-2">
                                <label for="productStock">Stock</label>
                                <input type="number" class="form-control" id="productStock" placeholder="Enter Stock" name="stock" value="<?php echo e($product['stock']); ?>">
                            </div>
                            <div class="form-group mt-2">
                                <label for="taxRate">Tax Rate</label>
                                <select class="form-control" id="taxRate" name="tax">
                                    <option value="0">Select Tax Rate</option>
                                    <option value="6" <?php if( $product['tax'] == "0"): ?> selected="" <?php endif; ?>>0%</option>
                                    <option value="6" <?php if( $product['tax'] == "6"): ?> selected="" <?php endif; ?>>6%</option>
                                  	<option value="16" <?php if( $product['tax'] == "16"): ?> selected="" <?php endif; ?>>16%</option>
                                </select>
                            </div>
                        </div>
                            
                        <div class="form-group mt-2">
                            <label class="form-label" for="customFile">Product Image</label>
                            <input type="file" name="image" class="form-control" id="customFile" onchange="loadFile(event)" />

                            
                            <img <?php if(count($product['media'])): ?> src="<?php echo e($product['media'][0]['url']); ?>" <?php else: ?> src="" <?php endif; ?> class="output_image" id="output">
                            
                        </div>
						
    					<button type="submit" id="submit_form" class="btn bg-gradient-dark mt-3">Submit</button>
					</form>
              	</div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<script src="//cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
       $('.ckeditor').ckeditor();
    });
</script>
<script type="text/javascript">


    $(document).ready(function(){
        $("#productType").on('change', function(){
            var type = $(this).val();
            var priceSection = $("#price_section");
            if(type == "storeWindow"){
                priceSection.css("display", "none");
            }
            else{
                priceSection.css("display", "block");
            }
        });

        $("#submit_form").click(function(e){
          e.preventDefault();

          var fieldsAreOk = true;

          var product_name = $("#productName").val();
          var type = $("#productType").val();
          

          if(!product_name){
            fieldsAreOk = false;
            toastr.error("Product Name is required.");
          }
          if(!type){
            fieldsAreOk = false;
            toastr.error("Product Type is required.");
          }
          else if(type == "product"){
            var tax = $("#taxRate").val();
            var price = $("#productPrice").val();
            if(!price || price == 0){
                fieldsAreOk = false;
                toastr.error("Price is required.");
            }
            if(!tax || tax == 0){
                fieldsAreOk = false;
                toastr.error("Tax is required.");
            }
          }
          if(fieldsAreOk){
            showLoader();
            $('#product_form').submit();
          }
          
        });

        $('#category_level_1').on('change', function(){
            var cat_id = $("#category_level_1").val();
            console.log(cat_id);
            $.ajax({
                type: "GET",
                url: "<?php echo e(url('get_subcategories')); ?>/"+cat_id,
                success:function(data){
                    data = $.parseJSON(data);
                    var dropDownOptions = `<option value="">Select Sub Category</option>`;
                    if(data.response && data.categories.length > 0){
                        
                        if(data.categories.length > 0){
                            $("#second_level_dropdown").css("display", "block");
                            resetLevelThreeDropdown();
                            $.each(data.categories, function(index, elem){
                                dropDownOptions += `<option value="${elem.id}">${elem.name}</option>`
                            });
                            $("#category_level_2").html(dropDownOptions);
                        }
                        else{
                            resetLevelTwoDropdown();
                            resetLevelThreeDropdown();

                        }
                            
                    }
                }
            })
        });

        $('#category_level_2').on('change', function(){
            var cat_id = $("#category_level_2").val();
            $.ajax({
                type: "GET",
                url: "<?php echo e(url('get_subcategories')); ?>/"+cat_id,
                success:function(data){
                    data = $.parseJSON(data);
                    var dropDownOptions = `<option value="">Select Sub Category</option>`;
                    if(data.response && data.categories.length > 0){
                        
                        if(data.categories.length > 0){
                            $("#third_level_dropdown").css("display", "block");
                            $.each(data.categories, function(index, elem){
                                dropDownOptions += `<option value="${elem.id}">${elem.name}</option>`
                            });
                            $("#category_level_3").html(dropDownOptions);
                        }
                        else{
                            resetLevelThreeDropdown();

                        }
                            
                    }
                }
            })
        });

        function resetLevelTwoDropdown(){
            $("#second_level_dropdown").css("display", "none");
            $("#category_level_2").html("");
            $("#category_level_2").val("");
        }
        function resetLevelThreeDropdown(){
            $("#third_level_dropdown").css("display", "none");
            $("#category_level_3").html("");
            $("#category_level_3").val("");
        }

    });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/orkiya-merchant/htdocs/merchant.orkiya.com/resources/views/products/edit.blade.php ENDPATH**/ ?>