<?php $__env->startSection('style'); ?>
<style type="text/css">
	.add-btn{
		margin-right: 15px;
		float: right;
	}
	.heading-style{
		display: inline;
	}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-12">
		<div class="card my-4">
            <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
            	<div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
            		<h6 class="text-white text-capitalize ps-3 heading-style"> Order No. <?php echo e($order['orderNumber']); ?></h6>
            		<?php if($status == "Open"): ?>
                		<span class="badge badge-sm bg-gradient-secondary">Open</span>
                	<?php endif; ?>

                	<?php if($status == "Paid"): ?>
                		<span class="badge badge-sm bg-gradient-info">Paid</span>
                	<?php endif; ?>

                	<?php if($status == "Complete"): ?>
                		<span class="badge badge-sm bg-gradient-success">Complete</span>
                	<?php endif; ?>
            	</div>
            </div>
            <div class="card-body px-0 pb-2">
            	<div class="row">
            		<div class="col-md-4">
            			<div class="card border-light mb-3" style="max-width: 30rem; margin-left: 20px;">
				  			<div class="card-header"><h5>Address</h5></div>
				  			<div class="card-body">
				    			<p class="card-text">
				    				<?php echo e($order['deliveries'][0]['shippingOrderAddress']['firstName']." ".$order['deliveries'][0]['shippingOrderAddress']['lastName']); ?> <br>
				    				<?php echo e($order['deliveries'][0]['shippingOrderAddress']['street']); ?> <br>
				    				<?php echo e($order['deliveries'][0]['shippingOrderAddress']['zipcode']); ?> <?php echo e($order['deliveries'][0]['shippingOrderAddress']['city']); ?> <br>

				    			</p>
				  			</div>
						</div>
            		</div>
            		<div class="col-md-4">
            			<div class="card border-light mb-3" style="max-width: 30rem; margin-left: 20px;">
				  			<div class="card-header"><h5><?php echo e($order['orderCustomer']['firstName']." ".$order['orderCustomer']['lastName']); ?>  can be reached via:</h5></div>
				  			<div class="card-body">
				    			<p class="card-text">
				    				<strong>Email:</strong> <?php echo e($order['orderCustomer']['email']); ?> <br>
				    				<?php if($order['deliveries'][0]['shippingOrderAddress']['phoneNumber']): ?>
			    					<strong>Phone No. :</strong> <?php echo e($order['deliveries'][0]['shippingOrderAddress']['phoneNumber']); ?>

			    					<?php endif; ?>
				    				
				    			</p>
				  			</div>
						</div>
            		</div>
            		<div class="col-md-4">
            			<div class="card border-light mb-3" style="max-width: 30rem; margin-left: 20px;">
				  			<div class="card-header"><h5>Comments</h5></div>
				  			<div class="card-body">
				    			<p class="card-text">
				    				<?php if( $order['customerComment'] ): ?>
				    					<?php echo e($order['customerComment']); ?> <br>
				    				<?php else: ?>
				    					No Comments <br>
				    				<?php endif; ?>

				    			</p>
				  			</div>
						</div>
            		</div>
            	</div>
            	<hr class="horizontal bg-gradient-secondary mt-2 mb-2">
            	<br>
            	<div class="table-responsive p-0">
            		<h5 class="text-capitalize ps-3">Products</h5>
            		<table class="table align-items-center justify-content-center mb-0">
            			<thead>
            				<tr>
	                      		<th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Name</th>
	                      		<th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Unit Price</th>
	                      		<th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Quantity</th>
	                      		<th class="text-uppercase text-secondary text-xxs font-weight-bolder text-center opacity-7 ps-2">Total</th>
                    		</tr>
                  		</thead>
	                  	<tbody>

	                  		<?php $__currentLoopData = $order['lineItems']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                    <tr>
		                      	<td>
		                        	<div class="d-flex px-2">
		                          		<div class="my-auto">
		                            		<h6 class="mb-0 text-sm"><?php echo e($item['label']); ?></h6>
		                          		</div>
		                    		</div>
		                      	</td>
		                      	<td>
		                    		<p class="text-sm font-weight-bold mb-0">Rs. <?php echo e($item['unitPrice']); ?></p>
		                      	</td>
		                      	<td>
		                        	<p class="text-sm font-weight-bold mb-0"><?php echo e($item['quantity']); ?></p>
		                      	</td>
		                      	<td class="align-middle text-center">
		                        	
                          			<p class="text-sm font-weight-bold mb-0">Rs. <?php echo e($item['totalPrice']); ?></p>
		                          	
		                        </td>

				            </tr>
				            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				            <hr class="horizontal bg-gradient-secondary mt-5 mb-5">	
				            <tr>	
	            				<td></td>
	            				<td></td>
	            				<td></td>
	            				<td></td>
				            </tr>
				            <tr>
				            	
				            	<td></td>
				            	<td></td>
				            	<td>
		                        	<div class="d-flex px-2">
		                          		<div class="my-auto">
		                            		<h6 class="mb-0 text-sm">Net Price</h6>
		                          		</div>
		                    		</div>
		                      	</td>
				            	<td class="align-middle text-center">
		                        	
                          			<p class="text-sm font-weight-bold mb-0">Rs. <?php echo e($order['price']['netPrice']); ?> </p>
		                          	
		                        </td>
				            </tr>
				            <tr>
				            	
				            	<td></td>
				            	<td></td>
				            	<td>
		                        	<div class="d-flex px-2">
		                          		<div class="my-auto">
		                            		<h6 class="mb-0 text-sm">Tax</h6>
		                          		</div>
		                    		</div>
		                      	</td>
				            	<td class="align-middle text-center">

				            		
				            		<?php
				            			$totaltax = 0;
				            			foreach($order['price']['calculatedTaxes'] as $tax){

				            				$totaltax += $tax['tax'];
				            			}
				            		?>
		                        	
                          			<p class="text-sm font-weight-bold mb-0">Rs. <?php echo e($totaltax); ?> </p>
		                          	
		                        </td>
				            </tr>

				            <tr>
				            	
				            	<td></td>
				            	<td></td>
				            	<td>
		                        	<div class="d-flex px-2">
		                          		<div class="my-auto">
		                            		<h6 class="mb-0 text-sm">Total</h6>
		                          		</div>
		                    		</div>
		                      	</td>
				            	<td class="align-middle text-center">
		                        	
                          			<p class="text-sm font-weight-bold mb-0">Rs. <?php echo e($order['amountTotal']); ?> </p>
		                          	
		                        </td>
				            </tr>
	                  		
			        	</tbody>
		    		</table>
				</div>

				<hr class="horizontal bg-gradient-secondary mt-5 mb-5">

				<div class="row">
					<div class="col-md-6">
						<button class="btn bg-gradient-primary mx-3" <?php if($status == "Complete" || $status == "Paid"): ?> disabled="" <?php endif; ?> onclick="markAsPaid()">Mark as Paid</button>
						<button class="btn bg-gradient-success" <?php if($status == "Complete" || $status == "Open"): ?> disabled="" <?php endif; ?> onclick="markAsDone()">Mark as Done</button>
					</div>
				</div>
			</div>
		</div>
    </div>
</div>
      
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
	function markAsPaid(){
		if (window.confirm('Are you sure and want to mark as paid?'))
		{
		    // They clicked Yes
		    showLoader();
		    window.location.replace( "<?php echo url('/orders/paid/'.$order['id']); ?>" );
		}
	}
	function markAsDone(){
		if (window.confirm('Are you sure and want to mark as done?'))
		{
		    // They clicked Yes
		    showLoader();
		     window.location.replace( "<?php echo url('/orders/done/'.$order['id']); ?>" );
		}
	}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/orkiya-merchant/htdocs/merchant.orkiya.com/resources/views/orders/view.blade.php ENDPATH**/ ?>