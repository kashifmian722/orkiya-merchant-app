@extends('layouts.app')

@section('style')
<style type="text/css">
	.form-control{
		padding: 1rem !important;
		background-color: #e5e5e5 !important;
	}
    .output_image{
        width: 25%;
    }
    #second_level_dropdown, #third_level_dropdown{
        display: none;
    }
</style>
@endsection

@section('content')
<div class="row">
    <div class="col-12">
    	<div class="card my-4">
    		<div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
    			<div class="bg-gradient-primary shadow-primary border-radius-lg pt-3 pb-4">
    				<div class="row">
	                    <div class="col-6 d-flex align-items-center">
	                    	<h6 class="text-white text-capitalize ps-3">Add Product</h6>
	                    </div>
                  	</div>
    			</div>
    		</div>
    		<div class="card-body px-0 pb-2">
    			<div class="table-responsive p-0">
    				<form class="align-items-center mx-5" id="product_form" action="{{ url('/products/add') }}" method="POST" enctype="multipart/form-data">
                        @csrf
    					<div class="form-group ">
    						<label for="productType">Product Type</label>
    						<select class="form-control" id="productType" name="type" required="">
                                <option value="">Select Product Type</option>
    							<option value="product">Product</option>
      							<option value="storeWindow">Showcase</option>
    						</select>
    					</div>
                        <div class="form-group ">
                            <label for="category">Category</label>
                            <select class="form-control" id="category_level_1" name="category_level_1">
                                <option value="">Select Category</option>
                                @foreach($categories as $cat)

                                    <option value="{{ $cat['id'] }}">{{ $cat['name'] }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group" id="second_level_dropdown">
                            <label for="category">Category</label>
                            <select class="form-control" id="category_level_2" name="category_level_2">
                                
                            </select>
                        </div>
                        <div class="form-group" id="third_level_dropdown">
                            <label for="category">Category</label>
                            <select class="form-control" id="category_level_3" name="category_level_3">
                                
                            </select>
                        </div>
    					<div class="form-group mt-2">
    						<label for="productName">Product Name</label>
    						<input type="text" class="form-control" id="productName" name="name" placeholder="Enter Product Name" required="">
    					</div>
    					<div class="form-group mt-2">
    						<label for="productDescription">Description</label>
                            <textarea class="form-control ckeditor" id="productDescription" name="description"></textarea>
    					</div>
    					<div class="form-group form-check form-switch ps-0 pt-3">
    						<input class="form-check-input ms-auto" type="checkbox" id="productStatus" name="status">
                            <label class="form-check-label text-body ms-3 text-truncate w-80 mb-0" for="productStatus">Active</label>
    					</div>
                        <div id="price_section">
                            <div class="form-group mt-2">
                                <label for="productPrice">Price</label>
                                <input type="number" class="form-control" id="productPrice" placeholder="Enter Price" name="price">
                            </div>
                            <div class="form-group mt-2">
                                <label for="productStock">Stock</label>
                                <input type="number" class="form-control" id="productStock" placeholder="Enter Stock" name="stock">
                            </div>
                            <div class="form-group mt-2">
                                <label for="taxRate">Tax Rate</label>
                                <select class="form-control" id="taxRate" name="tax">
                                    <option value="0">Select Tax Rate</option>
                                    <option value="0">0%</option>  
                                    <option value="6">6%</option>
                                  	<option value="16">16%</option>
                                </select>
                            </div>
                        </div>
                            
                        <div class="form-group mt-2">
                            <label class="form-label" for="customFile">Product Image</label>
                            <input type="file" name="image" class="form-control" id="customFile" onchange="loadFile(event)" />
                            <img src="" class="output_image" id="output">
                        </div>
                        
    					<button type="submit" id="submit_form" class="btn bg-gradient-dark mt-5">Submit</button>
					</form>
              	</div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')

<script src="//cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
       $('.ckeditor').ckeditor();
    });
</script>
<script type="text/javascript">


    $(document).ready(function(){
        $("#productType").on('change', function(){
            var type = $(this).val();
            var priceSection = $("#price_section");
            if(type == "storeWindow"){
                priceSection.css("display", "none");
            }
            else{
                priceSection.css("display", "block");
            }
        });


        $("#submit_form").click(function(e){
          e.preventDefault();

          var fieldsAreOk = true;

          var product_name = $("#productName").val();
          var price = $("#productPrice").val();
          var tax = $("#taxRate").val();
          var type = $("#productType").val();
          var organization = $("#organization").val();

          if(!product_name){
            fieldsAreOk = false;
            toastr.error("Product Name is required.");
          }
          if(!type){
            fieldsAreOk = false;
            toastr.error("Product Type is required.");
          }
          else if(type == "product"){
            if(!price || price == 0){
                toastr.error("Price is required.");
            }
            if(!tax || tax == 0){
                toastr.error("Tax is required.");
            }
          }
          if(fieldsAreOk){
            showLoader();
            $('#product_form').submit();
          }
          
        });



        $('#category_level_1').on('change', function(){
            var cat_id = $("#category_level_1").val();
            console.log(cat_id);
            $.ajax({
                type: "GET",
                url: "{{ url('get_subcategories') }}/"+cat_id,
                success:function(data){
                    data = $.parseJSON(data);
                    var dropDownOptions = `<option value="">Select Sub Category</option>`;
                    if(data.response && data.categories.length > 0){
                        
                        if(data.categories.length > 0){
                            $("#second_level_dropdown").css("display", "block");
                            resetLevelThreeDropdown();
                            $.each(data.categories, function(index, elem){
                                dropDownOptions += `<option value="${elem.id}">${elem.name}</option>`
                            });
                            $("#category_level_2").html(dropDownOptions);
                        }
                        else{
                            resetLevelTwoDropdown();
                            resetLevelThreeDropdown();

                        }
                            
                    }
                }
            })
        });

        $('#category_level_2').on('change', function(){
            var cat_id = $("#category_level_2").val();
            $.ajax({
                type: "GET",
                url: "{{ url('get_subcategories') }}/"+cat_id,
                success:function(data){
                    data = $.parseJSON(data);
                    var dropDownOptions = `<option value="">Select Sub Category</option>`;
                    if(data.response && data.categories.length > 0){
                        
                        if(data.categories.length > 0){
                            $("#third_level_dropdown").css("display", "block");
                            $.each(data.categories, function(index, elem){
                                dropDownOptions += `<option value="${elem.id}">${elem.name}</option>`
                            });
                            $("#category_level_3").html(dropDownOptions);
                        }
                        else{
                            resetLevelThreeDropdown();

                        }
                            
                    }
                }
            })
        });

        function resetLevelTwoDropdown(){
            $("#second_level_dropdown").css("display", "none");
            $("#category_level_2").html("");
            $("#category_level_2").val("");
        }
        function resetLevelThreeDropdown(){
            $("#third_level_dropdown").css("display", "none");
            $("#category_level_3").html("");
            $("#category_level_3").val("");
        }
    });

</script>
@endsection
